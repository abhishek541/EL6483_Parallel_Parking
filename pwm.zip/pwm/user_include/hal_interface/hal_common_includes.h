#ifndef HAL_COMMON_INCLUDES_H
#define HAL_COMMON_INCLUDES_H	1

#include "stm32f3xx_hal.h"
//#include "stm32f3xx_tim.h"
// #include "stm32f3xx_rcc.h"



#endif