/*
  This is the main user software application
  In this case, we have below the code necessary to use PWM with mtrs on an STM32 F3 Discovery PCB.

  (c) Abhimanyu Ghosh, 2017
 */

// C standard include(s):
#include <math.h>

// Custom user APIs needed for hardware access specific to this board:
#include "cpu.h"
#include "pwm_hal.h"
#include "board_led.h"
// #include "tm_stm32f4_hcsr04.h"
// Custom user APIs needed for generic algorithmic libraries that are hardware-independent:
#include "foo.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#define SR04_TRIG   (1<<6)
#define SR04_ECHO   (1<<7)
#define SR04_OFFSET 0.8

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
volatile uint32_t msTicks;
static volatile int button_pressed_flag; 

/* Private function prototypes -----------------------------------------------*/
int fputc(int ch, FILE * f);
void SysTick_Handler(void);
void Delay(uint32_t dlyTicks);
void USART1_IRQHandler(void);
void EXTI0_1_IRQHandler(void);
void button_init(void);
void USART1_Init(void);
void TIM2_Init(void);
float SR04read(void);
void SR04_Init(void);


void fwd()
{
    set_pwm(mtr1_pwm1, 0.7f);
    set_pwm(mtr1_pwm2, 0.0f);
    set_pwm(mtr2_pwm1, 0.7f);
    set_pwm(mtr2_pwm2, 0.0f);
}

void bkd()
{
    set_pwm(mtr1_pwm1, 0.0f);
    set_pwm(mtr1_pwm2, 0.7f);
    set_pwm(mtr2_pwm1, 0.0f);
    set_pwm(mtr2_pwm2, 0.7f);
}
void rgt()
{
    set_pwm(mtr1_pwm1, 0.0f);
    set_pwm(mtr1_pwm2, 0.7f);
    set_pwm(mtr2_pwm1, 0.7f);
    set_pwm(mtr2_pwm2, 0.0f);
}

void lft()
{
    set_pwm(mtr1_pwm1, 0.7f);
    set_pwm(mtr1_pwm2, 0.0f);
    set_pwm(mtr2_pwm1, 0.0f);
    set_pwm(mtr2_pwm2, 0.7f);
}
/*
  SysTick handler
 */
void SysTick_Handler(void) {
  msTicks++;
}

/*
  Function to provide delay (in mSec)
 */
void Delay (uint32_t delayTicks) {                                              
  uint32_t currentTicks;

  currentTicks = msTicks;
  while ((msTicks - currentTicks) < delayTicks);
}
/*
  Button interrupt handler
 */
void EXTI0_IRQHandler(void)
{
  HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_0);   // This function will first clear the IRQ on EXTI0
                      // It will then call the HAL_GPIO_EXTI_Callback below
}
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
  if(GPIO_Pin == GPIO_PIN_0) // This means we're sure we've gotten an EXTI event on pin 0
  {
    if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == GPIO_PIN_SET) // If the pin is high now, it must've been a
                                // RISING edge we captured
                                // I.e. the button was PRESSED
    {
      button_pressed_flag = 1; // Set the flag since we've detected a button press event
    }
  }
}
static void button_gpio_init(void)
{
  static GPIO_InitTypeDef  GPIO_InitStruct;
  /*
    PA0 Init
    Detect both edges, and route to the EXTI module so we can raise an interrupt accordingly
   */

  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;

  __HAL_RCC_GPIOA_CLK_ENABLE(); // Enable clock to GPIOA so PA0 works

  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct); // Done
}

void button_init(void)
{
  button_pressed_flag = 0;
  button_gpio_init(); // set up the PA0 GPIO pin so it can connect to the edge detection subsystem

  HAL_NVIC_SetPriority(EXTI0_IRQn, 3, 4); // Set the priority according to the application needs
  HAL_NVIC_EnableIRQ(EXTI0_IRQn); // Enable (un-mask) the EXTI0 interrupt in the NVIC
}

int button_pressed(button b)
{
  int ret = button_pressed_flag;  // Atomically save a copy of the button flag
  button_pressed_flag = 0;    // Zero it atomically before returning
  return ret; 
}

/*
  button gpio interrupt clock configuration
 */

void TIM2_Init(void) {
  uint16_t PrescalerValue = 0;
  
  TIM_HandleTypeDef   TIM_TimeBaseStructure;
  TIM_OC_InitTypeDef  TIM_OCInitStructure;

  /* TIM2 clock enable */
  __TIM2_CLK_ENABLE();

  HAL_TIM_Base_Init(&TIM_TimeBaseStructure);
  HAL_TIM_OC_Init(&TIM_OCInitStructure);

  /* Compute the prescaler value */
  PrescalerValue = (uint16_t) (SystemCoreClock / 1000000) - 1;

  /* Time base configuration */
  TIM_TimeBaseStructure.Period = 65535 - 1;      //in uSecs
  TIM_TimeBaseStructure.Prescaler = PrescalerValue;
  TIM_TimeBaseStructure.ClockDivision = TIM_CLOCKDIVISION_DIV0;
  TIM_TimeBaseStructure.CounterMode = TIM_COUNTERMODE_UP;
  TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);

  TIM_Cmd(TIM2, ENABLE);
}
/*
returns SR04 measurement in cm
 */
float SR04read(void) {
  TIM_SetCounter(TIM2, 0);
  GPIO_SetBits(GPIOA, SR04_TRIG);
  while(TIM_GetCounter(TIM2) < 15);
  GPIO_ResetBits(GPIOA, SR04_TRIG);
  //TIM_SetCounter(TIM2, 0);
  while(!GPIO_ReadInputDataBit(GPIOF, SR04_ECHO));// & (TIM_GetCounter(TIM2) < 50000));
  TIM_SetCounter(TIM2, 0);
  while(GPIO_ReadInputDataBit(GPIOF, SR04_ECHO));// & (TIM_GetCounter(TIM2) < 50000));
  return ((float)TIM_GetCounter(TIM2) * 0.01715 + SR04_OFFSET);
}

/*
  Configure SR04 GPIO
 */
void SR04_Init(void) {

  static GPIO_InitTypeDef GPIO_InitStructure;
  
  // configuring clock sources for GPIOC
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /* Configure SR04 pins: PA12 - TRIGGER */
  GPIO_InitStructure.Pin =  GPIO_PIN_12;
  GPIO_InitStructure.Speed = GPIO_SPEED_FREQ_HIGH;
  GPIO_InitStructure.Mode = GPIO_MODE_OUTPUT_PP;;
  GPIO_InitStructure.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStructure);

  __HAL_RCC_GPIOF_CLK_ENABLE();
  /* Configure SR04 pins: PF6 - ECHO */
  GPIO_InitStructure.Pin =  GPIO_PIN_6;
  GPIO_InitStructure.Speed = GPIO_SPEED_FREQ_HIGH;
  GPIO_InitStructure.Mode = GPIO_MODE_OUTPUT_PP;;
  GPIO_InitStructure.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOF, &GPIO_InitStructure);

  // hold TRIG pin low
  GPIO_ResetBits(GPIOA, SR04_TRIG);
}

int main()
{
  /*
    Initialize the PLL, clock tree to all peripherals, flash and Systick 1 ms time reference:
   */
  button_init();
  TIM2_Init();
  SR04_Init();
  cpu_init();
  board_led_init();
  uart_debug_init();

  setvbuf(stdin,NULL,_IONBF,0);   // Sets stdin in unbuffered mode (normal for usart com)
  setvbuf(stdout,NULL,_IONBF,0);  // Sets stdin in unbuffered mode (normal for usart com)
  
  printf("Hello World!!\r\n");

  /*
    WARNING: We cannot use one of the GPIOs (PE9) from board_mtr since it is now being used for PWM!!
   */

  /*
    Initialize the PWM outputs for PE9 and PE11 which are connected to LD3 and LD7:
   */
  init_pwm();

  int i = 0;
  int cnt = 0;
  float dist = 0.0f;
  /*
    In an infinite loop, keep toggling the mtrs in an alternating pattern:
   */
  while(1)
  {
    /*
      Carry out a simple unit test of foo() declared in foo.h:
     */
    if(TEST_FOO(i, i+1) < 0)
    {
      /*
        If the above fails there is either a hardware, code or other undefined error.
        Now we're in an undefined state regarding processor core behavior...
       */
      while(1); // We probably have had a radiation hit or a major malfunction on the ALU of the processor...
    }
    else
    {
        printf("Distance:\t%.2f\tcm\r\n", SR04read());
        Delay(1000);
    }  
  }

  return 0;
}
